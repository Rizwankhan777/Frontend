<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="footer-col-1">
                    <h1>LOGO</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'</p>
                    <h6>SUBSCRIBE TO NEWSLETTER</h6>
                    <div class="footer-form">
                        <span class="input"><input type="text" class="form-control"></span>
                        <span class="arrow"><a href="#"><i class="fa-solid fa-arrow-right"></i></a></span>
                    </div>







                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-col-2">
                    <h6>QUICK LINKS</h6>
                    <ul>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">SERVICES</a></li>
                        <li><a href="#">CONTACT</a></li>
                        <li><a href="#">GALLERY</a></li>
                        <li><a href="#">PRODUCT</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-col-2">
                    <h6>SERVICES</h6>
                    <ul>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">SERVICES</a></li>
                        <li><a href="#">CONTACT</a></li>
                        <li><a href="#">GALLERY</a></li>
                        <li><a href="#">PRODUCT</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="footer-col-4">
                    <h6>GET IN TOUCH</h6>
                    <ul>
                        <li><a href="#"><i class="fa-solid fa-phone"></i> +1 (156) 4764</a></li>
                        <li><a href="#"><i class="fa-solid fa-envelope"></i> info@mail.com.</a></li>
                        <li><a href="#"><i class="fa-solid fa-location-dot"></i> 14th street, Malobo Beach, Canada.</a></li>
                    </ul>
                    <div class="social-icons">
                        <span><a href="#"><i class="fa-brands fa-facebook-square"></i></a></span>
                        <span><a href="#"><i class="fa-brands fa-twitter-square"></i></a></span>
                        <span><a href="#"><i class="fa-brands fa-instagram"></i></a></span>
                        <span><a href="#"><i class="fa-brands fa-youtube"></i></a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<script src="js/aos.js"></script>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/popper-min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="OwlCarousel/dist/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>
<script>
    AOS.init();
</script>
</body>

</html>