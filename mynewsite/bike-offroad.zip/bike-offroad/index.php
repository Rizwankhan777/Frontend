<?php include 'header.php'; ?>
<!---------------------------------------------- Banner ------------------------------------------------->
<section class="banner-1 bike-img banner-main-wrap">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 pl-0">
                <div class="inner-image">
                    <img src="./images/main-img/banner-1/bike-2.png" class="img-fluid" alt="" />
                </div>
            </div>
            <div class="col-md-6 align-self-center">
                <div class="off-road">
                    <h1> OFF ROAD </h1>
                </div>
                <div class="banner-content" data-aos="fade-right" data-aos-duration="3000">
                    <h4>DIRT <span> BIKE </span> EVENT</h4>
                    <h1>OFF ROAD</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the </p>
                    <div class="learn-more">
                        <a href="#">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-------------------------------section-1------------------------------------------------------------>
<section class="section-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading text-center ">
                    <h1>FEATURED PRODUCT</h1>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-1.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-2.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-3.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-4.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-1.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-2.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-3.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-4.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-1.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-2.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-3.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="img-div text-center">
                    <a href=""><img src="./images/main-img/section-1/img-4.png" class="img-fluid" alt=""></a>
                    <div class="img-div-text pt-2">
                        <h5>Lorum Ipsum</h5>
                        <p>$70.00</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!---------------------------------------------- section-2 -------------------------------------->
<section class="section-2 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="section-2-text" data-aos="fade-up" data-aos-duration="3000">
                    <h6>ABOUT US</h6>
                    <h1>LORUM IPSUM LORUM</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <div class="learn-btn">
                        <a href="#">LEARN MORE</a>
                    </div>
                </div>
            </div>
            <div class="col-md-7 p-0">
                <div class="engine-img ">
                    <img src="./images/main-img/section-2/engine.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!---------------------------------------------- section-3 ------------------------------------->
<section class="section-3 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-7 order-2 order-md-1 p-0">
                <div class="engine-img">
                    <img src="./images/main-img/section-3/engine.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-md-5 order-1">
                <div class="section-3-text" data-aos="fade-down" data-aos-duration="3000">
                    <h6>ABOUT US</h6>
                    <h1>LORUM IPSUM LORUM</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <div class="learn-btn">
                        <a href="#">LEARN MORE</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!---------------------------------------------- section-4 ------------------------------->
<section class="section-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-4-heading text-center">
                    <h1>NEW ARRIVALS</h1>
                </div>
                <div class="col-md-12">
                    <div class="section-4-carasoul">
                        <div class="new-arrival owl-carousel owl-theme">
                            <div class="item">
                                <div class="carasoul-img-div text-center">
                                    <img src="./images/main-img/section-1/img-1.png" class="img-fluid" alt="">
                                    <div class="carasoul-img-div-text">
                                        <h5>Lorum Ipsum</h5>
                                        <p>$70.00</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="carasoul-img-div text-center">
                                    <img src="./images/main-img/section-1/img-2.png" class="img-fluid" alt="">
                                    <div class="carasoul-img-div-text">
                                        <h5>Lorum Ipsum</h5>
                                        <p>$70.00</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="carasoul-img-div text-center">
                                    <img src="./images/main-img/section-1/img-3.png" class="img-fluid" alt="">
                                    <div class="carasoul-img-div-text">
                                        <h5>Lorum Ipsum</h5>
                                        <p>$70.00</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="carasoul-img-div text-center">
                                    <img src="./images/main-img/section-1/img-4.png" class="img-fluid" alt="">
                                    <div class="carasoul-img-div-text">
                                        <h5>Lorum Ipsum</h5>
                                        <p>$70.00</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!---------------------------------------------- section-5 -------------------------->
<section class="section-5">
    <div class="container-fluid">
        <div class="row">
            <div class="testemonials col-md-6 text-center align-self-center">
                <h1>WHAT CLIENTS SAY</h1>
                <div class="row d-flex justify-content-center">
                    <div class="col-md-10">
                        <div id="myCarousel" class="carousel  slide" data-ride="carousel" align="center">
                            <div class="carousel-inner">
                                <div class="carousel-item">
                                    <div class="desc">
                                        <img src="./images/main-img/section-5/quote-1.png" class="img-fluid" alt="">
                                        <p>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                        </p>
                                        <img src="./images/main-img/section-5/quote-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="name">
                                        <p>MARTIN FRANK - Designer</p>
                                    </div>
                                </div>
                                <div class="carousel-item active">
                                    <div class="desc">
                                        <img src="./images/main-img/section-5/quote-1.png" class="img-fluid" alt="">
                                        <p>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                        </p>
                                        <img src="./images/main-img/section-5/quote-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="name">
                                        <p>MARTIN FRANK - Designer</p>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="desc">
                                        <img src="./images/main-img/section-5/quote-1.png" class="img-fluid" alt="">
                                        <p>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                        </p>
                                        <img src="./images/main-img/section-5/quote-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="name">
                                        <p>MARTIN FRANK - Designer</p>
                                    </div>
                                </div>


                            </div>
                            <ol class="carousel-indicators list-inline">
                                <li class="list-inline-item">
                                    <a id="carousel-selector-0" class="selected" data-slide-to="0" data-target="#myCarousel"> <img src="./images/main-img/section-5/male-1.png" class="testimonials-img-select"> </a>
                                </li>
                                <li class="list-inline-item active">
                                    <a id="carousel-selector-1" data-slide-to="1" data-target="#myCarousel"> <img src="./images/main-img/section-5/male-2.png" class="testimonials-img-select"> </a>
                                </li>
                                <li class="list-inline-item">
                                    <a id="carousel-selector-2" data-slide-to="2" data-target="#myCarousel"> <img src="./images/main-img/section-5/male-3.png" class="testimonials-img-select"> </a>
                                </li>

                            </ol>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-6 p-0">
                <div class="section-5-img">
                    <img src="./images/main-img/section-5/background-img.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!---------------------------------------------- section-6 -------------------------->
<section class="section-6">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-6-heading text-center" data-aos="zoom-in" data-aos-duration="3000">
                    <h6>WHAT WE SHARE</h6>
                    <h1>BLOGS & NEWS</h1>
                </div>
            </div>
            <div class="col-md-4">
                <div class="images-div" data-aos="zoom-in" data-aos-duration="3000">
                    <a href=""><img src="./images/main-img/section-6/img-1.jpg" class="img-fluid" alt=""></a>
                    <h6>Lorem Ipsum is simply dummy text of the printing and</h6>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="images-div" data-aos="zoom-in" data-aos-duration="3000">
                    <a href=""><img src="./images/main-img/section-6/img-2.jpg" class="img-fluid" alt=""></a>
                    <h6>Lorem Ipsum is simply dummy text of the printing and</h6>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="images-div" data-aos="zoom-in" data-aos-duration="3000">
                    <a href=""><img src="./images/main-img/section-6/img-3.jpg" class="img-fluid" alt=""></a>
                    <h6>Lorem Ipsum is simply dummy text of the printing and</h6>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>
                </div>
            </div>

        </div>
    </div>
</section>
<!---------------------------------------------- section-7 --------------------->
<section class="section-7">
    <div class="container">
        <div class="row">
            <div class="col-md-6 ">
                <div class="section-7-text" data-aos="flip-left" data-aos-duration="3000">
                    <h3>GET IN TOUCH</h3>
                    <h1>SEND US A MESSAGE</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industr</p>
                    <div class="phone-number">
                        <a href="#"><i class="fa-solid fa-phone"></i> +1 234 4657</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="section-7-form " data-aos="flip-right" data-aos-duration="3000">
                    <form class="custom-form">
                        <div class="form-row mb-3">
                            <div class="col-6">
                                <input type="text" class="form-control" placeholder="First name">
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control" placeholder="Last name">
                            </div>
                        </div>
                        <div class="form-row mb-3">
                            <div class="col-12">
                                <input type="email" class="form-control" placeholder="email address">
                            </div>
                        </div>
                        <div class="form-row mb-3">
                            <div class="col-12">
                                <input type="phone" class="form-control" placeholder="phone number">
                            </div>
                        </div>
                        <div class="form-row mb-3">
                            <div class="col-12">
                                <textarea class="form-control" rows="7" placeholder="your message"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col text-center">
                                <button type="submit" class="btn custom-button">SEND</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>