<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<title>Title</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="icon" href="images/favicon.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="./css/bootstrap.min.css" />
	<link rel="stylesheet" href="fontawesome/css/all.min.css">
	<link rel="stylesheet" href="OwlCarousel/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="OwlCarousel/dist/assets/owl.theme.default.css">
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link rel="stylesheet" href="./css/style.css" />
	<link rel="stylesheet" href="css/responsive.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

</head>

<body>
	<header>
		<div class="mobile-header">
			<div class="container">
				<div class="row">
					<div class="col-6 align-self-center">
						<div class="mobile-logo-main">
							<a href="index.php"><img src="./images/header-img/img-1.jpg" class="img-fluid"></a>
						</div>
					</div>
					<div class="col-6">
						<div class="mobile-menu">
							<div class="circle" id="navbar"><i class="fa fa-bars" aria-hidden="true"></i></div>
							<div class="nveMenu text-left">
								<div class="mobile-cross close-btn-nav" id="navbar"><i class="fas fa-times" aria-hidden="true"></i></div>
								<ul class="navlinks p-0 mt-4">
									<li><a href="index.php" class="active">home</a></li>
									<li>
										<div class="dropdown">
											<a href="#">Product <i class="fa-solid fa-chevron-down"></i></a>
											<div class="dropdown-content">
												<a href="#">Generic</a>
												<a href="#">Element</a>
											</div>
										</div>
									</li>
									<li><a href="#"> Gallery </a></li>
									<li><a href="#"> Contact us </a></li>
									<li><a href="#"> About us </a></li>
									<li><a href="#"><input type="text" class="form-control" placeholder="search"></a></li>
								</ul>

							</div>
							<div class="overlay"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="desktop-header">
			<div class="container">
				<div class="row">
					<div class="col-md-2">
						<div class="header-img">
							<img src="./images/header-img/img-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
					<div class="col-md-6">
						<div class="header-ul">
							<ul>
								<li><a href=""> Home </a></li>
								<li>
									<div class="dropdown">
										<a href="#">Product <i class="fa-solid fa-chevron-down"></i></a>
										<div class="dropdown-content">
											<a href="#">Generic</a>
											<a href="#">Element</a>
										</div>
									</div>
								</li>
								<li><a href=""> Gallery </a></li>
								<li><a href=""> Contact us </a></li>
								<li><a href=""> About us </a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="header-third">
							<div class="header-search">
								<input type="text" class="form-control" placeholder="search">
								<i class="fa-solid fa-magnifying-glass search-icon"></i>
							</div>
							<div class="cart">
								<i class="fa-solid fa-cart-shopping header-cart"></i>
							</div>
							<div class="header-btn">
								<a href="#">Appointment</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- PRELOADER START -->
	<!-- <div class="preloader"></div> -->
	<!-- PRELOADER END -->


	<!-- 
	fancybox images link
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
 -->