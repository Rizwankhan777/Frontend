
<footer class="footer_section">

<div class="container">
	<div class="row ">
		<div class="col-md-3">
			<div class="footer_links">
				<h4>NEED HELP?</h4>
				<ul>
					<li><a href="javascript:;">FAQs</a></li>
					<li><a href="javascript:;"> Returns / Refunds</a></li>
					<li><a href="javascript:;">Order Status</a></li>
					<li><a href="javascript:;">Payments</a></li>
					<li><a href="javascript:;">Contact Us</a></li>

				</ul>
			</div>
			
		</div>
		
		<div class="col-md-3">
			<div class="footer_links">
				<h4>COMPANY INFO</h4>
				<ul>
					<li><a href="javascript:;">Accessibility Statement</a></li>
					<li><a href="javascript:;">Our Blog</a></li>
					<li><a href="javascript:;">About Us</a></li>
					<li><a href="javascript:;">Privacy Policy</a></li>
					<li><a href="javascript:;">Legal Notice</a></li>
					<li><a href="javascript:;">Shop Canada</a></li>
					<li><a href="javascript:;">Careers</a></li>

				</ul>
			</div>

		</div>

		<div class="col-md-3">
			<div class="footer_links">
				<h4>CONTACT US</h4>
				<ul>
					<li><a href="javascript:;">1 (000) 022-7210</a></li>
					<li><a href="javascript:;">Mon - Fri 9 am - 11 pm EST</a></li>
					<li><a href="javascript:;">Sat - Sun 9 am - 6 pm EST</a></li>
				</ul>
			</div>

		</div>

		<div class="col-md-3">
			<div class="footer_links">
			<h4>NEWSLETTER</h4>

			<div class="input_field">
				<input type="email" class="form-control" placeholder="email address"><span><i class="fa-solid fa-paper-plane" style="color: #302f2f;"></i></span>
			</div>

			<div class="pay_links">

				<div class="links_icon">
					<span><i class="fa-brands fa-apple-pay" style="color: #fff;"></i></span>
				</div>

				<div class="links_icon">
					<span><i class="fa-brands fa-amazon-pay" style="color: #fff;"></i></span>
				</div>

				<div class="links_icon">
					<span><i class="fa-brands fa-cc-amex" style="color: #fff;"></i></span>
				</div>

				<div class="links_icon">
					<span><i class="fa-brands fa-cc-discover" style="color: #ffffff;"></i></span>
				</div>

			</div>
		
			</div>

			<div class="social_links">

				<a href=""><i class="fa-brands fa-facebook" style="color: #fff;"></i></a>
				<a href=""><i class="fa-brands fa-instagram" style="color: #fff;"></i></a>
				<a href=""><i class="fa-brands fa-amazon" style="color: #fff;"></i></a>
				
			</div>

		</div>
	</div>
</div>

</footer>



	<!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->
	<?php include 'inc/script.php' ?>


	</body>

	</html>