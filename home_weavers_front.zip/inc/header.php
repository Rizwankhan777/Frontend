<!doctype html>
<html>
<head>
	<title>Home Weavers</title>
<?php include 'inc/styles.php' ?>
</head>
<body>
	<header>
		<div class="mobile-menu">
		<div class="mobile-top">
			<div class="img-div">
				<img src="./images/logo.png" class="img-fluid" alt="">
			 </div>
			 <div class="circle" id="navbar"><i class="fa fa-bars" aria-hidden="true"></i></div>
		</div>
	    	<div class="nveMenu text-left">
			<div class="mobile-cross close-btn-nav" id="navbar"><i class="fas fa-times" aria-hidden="true"></i></div>
				<div>
					<a href="index.php"><img src="images\logo.png" class="img-fluid"></a>
				</div>
				<ul class="navlinks p-0 mt-4">
				<li><a href="javascript:;">Rugs</a></li>
						<li><a href="javascript:;">Bedding</a></li>
						<li><a href="javascript:;">Furniture</a></li>
						<li><a href="javascript:;">Home Decor</a></li>
						<li><a href="javascript:;">Bath</a></li>
						<li><a href="javascript:;">Youth</a></li>
						<li><a href="javascript:;">Window</a></li>
						<li><a href="javascript:;">Outdoors</a></li>
						<li><a href="javascript:;">Pets</a></li>
						<li class="input_div">
							<input type="text" placeholder="I'm looking for..." class="form-control">
							<i class="fa-solid fa-magnifying-glass"></i>
						</li>
						<li><a href="#"><i class="fa-solid fa-user"></i></a></li>
						<li><a href="#"><i class="fa-regular fa-heart"></i></a></li>
						<li class="cart_input"><a href="#"><span>$ 4000</span> <i class="fa-solid fa-bag-shopping"></i></a></li>
				</ul>


				

			</div>
			<div class="overlay"></div>
		</div>
		<div class="desktop-header">
			<div class="container mb-2">
				<div class="row">
				<div class="col-md-5">
					<div class="logo-img">
						<img src="./images/logo.png" class="img-fluid" alt="">
					</div>
				</div>
				<div class="col-md-7">
					<ul class="header_top_links">
						<li class="input_div">
							<input type="text" placeholder="I'm looking for..." class="form-control">
							<i class="fa-solid fa-magnifying-glass"></i>
						</li>
						<li><a href="#"><i class="fa-solid fa-user"></i></a></li>
						<li><a href="#"><i class="fa-regular fa-heart"></i></a></li>
						<li class="cart_input"><a href="#"><span>$ 4000</span> <i class="fa-solid fa-bag-shopping"></i></a></li>
						<li>
							<!-- Default dropright button -->
							<div class="btn-group dropright">
							<button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAACuCAMAAAClZfCTAAABAlBMVEX///+/CzAAJ2i+ACf///y8ABu+ACzTZHbGPVD57/DntLzPbHa7AA6/ABy+ACHioavcj5v35+rmuL3fpazn5+e7ABLVbX3nvL3AADAAJmoAKGYAEV4AC10AHWbr7/Jxe5etsb/U2+S8xdZJW4vtyM0AAFu9DzU1IWDKTGLqwMfJBy0AAFkAAGMAAFMAJm0GK2cAG2iBkKfw+f01THlIWoOLmbLJ0d4ACWG8AADj2NnT09Pb4+XCx87Uq66bpLI0S3XSu8AtG1EvR3dBPXHRgo4AF2lOX4YjPXKfqL0+RXXUkZwWNHIuGmDiwsLFLknOKkNZbI9ufZV3YYCRobobAEuomKtQd7lJAAAHKklEQVR4nO2de3vaNhSHVcXQdS10JWStBHYDjdMLDpAbNAlNLxtZ2u7SLtv3/yqzoEmwdcQRWfoQn5z3z0bW8/h9zk82sqSKw/o5Rx9C3YOQ4Si6X96cofomOg7Btlo3ty96rNdKd4qPqIsLdnb7Wtpo1WyJn1dmr6rUxHoDaJo2Hm5fdig2qCkKdt6GykZ2h3lFpcepIqCp0sm2CAgrMnUUSquQgCqaKLIrSKt4toYIKgrSOtrt+wQNVqRknKkhgoqMJMCRfxUl2RoiqWg6HuWy5qnIShlVRcKuI98q6uRSRlXRt/FIL6ZIQymjqiiVFOzsZerIp4qglJFRdBTk05GSyZqPIgWkLOVdZVn3dY2I3Z38rZms7c1kDVPkSlkgWu9fLeu+rhERGkc5S9msoVWkJWRIiNb4eaVafITqf9iB7m8v9FbkSNlR0vvlp+Lzq5Ay/ABlTTw7z9p8RVrqeB9MWVOGzyD5BSNKFUlX1sY+VZSmDDBkUqakoqCobhSp/i6ctb6HIkfKWuO0BOkoSuvoLZA18S1rcxRp5UpZLLu0FE3HIytrYpK1uVXkSNlQTSqMkiIVws+1k/58RfEZlLLBt9lLUoqmWcuXkZiMRy5FzpQNGkpRVCT7cNZOxs4q0nDKDhN1/sJETJEKf7Ozlio7CV2K4mMwZclll8QUTcds4J5PGrCidByymKSMsCJn1mJIUQcwJMRoPNMfPUVaplmzysg8+wFFp+Ab4yBR1BRFmSqSE0fAnUe2oshulaYsnjUk1ceHxedTTlHqKLKyZgrJUgTV0GiY+zDwvFIqPNWcIpM1oD4EoMhmMJYqp4jElJrMYxzZFeKhKJcyA1FFsp9mzRqQcEWjpGd1RVRRmrXPkTXUzFcUmBoyv+1vhyI4a1gVtZtWykgrmmZtEUVQysgo0gA9rT5HiygaxT0FdURDEbSQKiXUkb+iUezohch3NAfjXuSrqJ24Ovm9XF7WjV0f4jByEjgVVWozfwrqzh7ePXhSLjzQby2IjKJy6Q+/q2gse/jBj83MVeU//a766/WDwrMmPKsta2jT76KVF37FdqOpi+9ZoqyIFbGiCawIhRWhsCIUVoTCilBYEQorQmFFKL6K8tM+m2Ar66oX9x4VngNRWvMiO31YrvhdRWFl+oo48FJ57+7sfNFmZdWvPGpVCrOOV5lSc3ywttlYW9Z9XSPiqYOvX1q+itpfvjo6+XuFQhW5ZuY768I9d52roq8x3Eefxkci6Auh1t143TtoQSC2Y/tjtaS7MmRCroaQKkodDcFuiCrSaRHF7fzAO19RIJ4mgCGqiqTudixD2MoQR9aoKlJbbXsNFvbQN45uhyKzVnFo15CHItARRUVwyjwUTRx18lkjqagLpcxH0SRrnbyitWWvd/3/VLNL06W0n2UuRdAa9v1s1tTHx7XC8yZTRVqB45A4PQQ2OAzsvRAidTSbNRKr97MbHBwpO92C9oBstfLtjLPtLbqKTMqgkToQxzF4UNiwYTkyrWezRkyRORkFTlni2I/WDR1ZU0QV6W4TTlnSc238TB3lWxtn+x2SirSSTTBlp2lunNuHu2ELeLCJ/SZFRa6n/Wkyd4d1t9GalzVKirTqDMCUxRI5yqBhZy24yBodRXNThhxloELQ7VlHkVLk+OUqjhOJKkqzNrDetE3WzHkPdBSpeAQ/y5SHovSvVtYmjjpkFGllxiGLQJydvwNiRzyZ8QjOGhFFSg4BQxcp81CkwawZx929e8XnQKjmyNITTJ/2noqcWTuLn796UnwElDJxmTIfRe6s/fPqzlV3XtwY7gjwV8dxohdSBD/XAvEviXMd7dNBJzWkFlMkJ1mznv0bFb9VNjcaW1E2Zb6KJPCeTWUnka3oOLfP1fOk4i4wHlFUZFKW6O5VFEk1tLJGUZHIz9AvoEgqa9aSpKJ8yhZRNJ2VCygrglK2kCIt42zWyClKUwat7/BWZLKWnVWhp2gfPLNhEUW570zEFJlvYI1hE6KTKnpQuaT0uibWO1DLRrO5NVNHL1+XKoVnpoqitoNROxIbL2epPRJHrtbtmZ/Fjx6uFp5P0Nu1H9DiiOm/u/5STKLME82B49rFWheW+tWr6LbAilBYEQorQmFFKKwIhRWhsCIUo8j1xsgYUkGeuxpvL5G4yyCIFQbhux5lQANWhMKKUFgRCitCYUUorAiFFaGwIhRWhOJ7UvEtxve861sMT4ZgRDzriMETsyisCIUVobAiFFaEwopQWBEKK0JhRSisCKUuDpa9PfemcyDWlv0/R9101nhKDYUVobAiFFaEwopQWBEKK0JhRSisCIUVobAiFFFd9nnSN52qWP2Rmcsqf7DG4A/WKDzriMKKUFgRCitCYUUorAiFFaGwIhRWhMKKUHiHNUok7jMIvMMahWcdUVgRCitCYUUorAiFFaGwIhRWhMKKUFgRCitCYUUo/wFtBFTJCfVFRQAAAABJRU5ErkJggg==" alt=""><span>ENG</span>
							</button>
							<div class="dropdown-menu">
							<a class="dropdown-item" href="#">ENG</a>
							<a class="dropdown-item" href="#">ENG</a>
							<a class="dropdown-item" href="#">ENG</a>
							<!-- <div class="dropdown-divider"></div>
							<a class="dropdown-item" href="#">ENG</a>
							</div> -->
							</div>
						</li>
					</ul>
				</div>
				</div>
			</div>
			<div class="main_header_links">
			<div class="container">
			<div class="row">
				<div class="col-md-10 mx-auto">
					<ul>
						<li><a href="javascript:;">Rugs</a></li>
						<li><a href="javascript:;">Bedding</a></li>
						<li><a href="javascript:;">Furniture</a></li>
						<li><a href="javascript:;">Home Decor</a></li>
						<li><a href="javascript:;">Bath</a></li>
						<li><a href="javascript:;">Youth</a></li>
						<li><a href="javascript:;">Window</a></li>
						<li><a href="javascript:;">Outdoors</a></li>
						<li><a href="javascript:;">Pets</a></li>
					</ul>
				</div>
				</div>
			</div>
			</div>
			
		</div>
	</header>
    
<!-- PRELOADER START -->
	<div class="preloader"></div>
<!-- PRELOADER END -->

	
<!-- 
	fancybox images link
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
 -->