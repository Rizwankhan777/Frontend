///////////////*****//////////////////
// RESPONSIVE NAVIGATION
// OPEN BTN
  $(document).ready(function () {
    $("#navbar").on("click", function() {
      $(".nveMenu").addClass("is-opened");
      $(".overlay").addClass("is-on");
    });

    $(".overlay").on("click", function() {
      $(this).removeClass("is-on");
      $(".nveMenu").removeClass("is-opened");
    });
  });
// CLOSE BTN
  $(".overlay").on("click", function() {
    $(this).removeClass("is-on");
    $(".nveMenu").removeClass("is-opened");
  });

  $(".close-btn-nav").click(function(){
  $(".nveMenu").removeClass("is-opened");
  $(".overlay").removeClass("is-on");
  });
  // RESPONSIVE NAVIGATION
  // 
  // ACTIVE JS START
$(document).ready(function(){
  $('ul li span').click(function(){
    $('li span').removeClass("active-class");
    $(this).addClass("active-class");
});
});
  // ACTIVE JS END
  // 
  // PRELOADER START
$(document).ready(function() {
  setTimeout(function() {
  $('.preloader').fadeOut('slow');
            }, 2000);
});
  // PRELOADER END
///////////////*****//////////////////

//browse carousel

$('.browse-carousel').owlCarousel({
  loop:true,
  margin:30,
  nav:false,
  responsive:{
      0:{
          items:1
      },
      600:{
          items:3
      },
      1000:{
          items:3
      }
  }
})

// top selling carousel

$('.top_selling_carousel').owlCarousel({
  loop:true,
  margin:20,
  nav:false,
  dots:false,
  responsive:{
      0:{
          items:1
      },
      600:{
          items:3
      },
      1000:{
          items:4
      }
  }
})

var selector1 = $('.top_selling_carousel');
$('.my-next-button1').click(function() {
  selector1.trigger('next.owl.carousel');
});

$('.my-prev-button1').click(function() {
  selector1.trigger('prev.owl.carousel');
});

// banner section

$('.banner-carousel').owlCarousel({
  center: true,
  items:2,
  loop:true,
  dots:false,
  margin:30,
  responsive:{
      0:{
          items:1
      },
      600:{
          items:1
      },
      1000:{
        items:2
    },
  }
});

var selector = $('.banner-carousel');
$('.my-next-button2').click(function() {
  selector.trigger('next.owl.carousel');
});

$('.my-prev-button2').click(function() {
  selector.trigger('prev.owl.carousel');
});
