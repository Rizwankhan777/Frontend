<?php include 'inc/header.php';?>

<div class="banner_main_div">
<div class="banner-carousel owl-carousel owl-theme">
	<div class="item">
	<section class="banner_section">
	<div class="container">
		<div class="row">
			<div class="col-md-10 mx-auto">
				<div class="banner_content text-center">
				<h1>Transform Your Space With Our 
Home Decor And Furniture.</h1>
				<p>Lorem Ipsum is simply dummy textl the printingtypesetting industry Lorem Ipsum has been </p>
				<div class="actionButton mt-3">
					<button>Shop Now</button>
				</div>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
	<div class="item">
	<section class="banner_section">
	<div class="container">
		<div class="row">
			<div class="col-md-8 mx-auto">
				<div class="banner_content text-center">
				<h1>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h1>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur architecto, 
				iusto harum iste unde et aperiam!</p>
				<div class="actionButton mt-3">
					<button>Shop Now</button>
				</div>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
	<div class="item">
	<section class="banner_section">
	<div class="container">
		<div class="row">
			<div class="col-md-8 mx-auto">
				<div class="banner_content text-center">
				<h1>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h1>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur architecto, 
				iusto harum iste unde et aperiam!</p>
				<div class="actionButton mt-3">
					<button>Shop Now</button>
				</div>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
   
</div>

		<div class="my-owl-nav2">
		<span class="my-next-button2">
			<i class="fa-solid fa-angle-left" aria-hidden="true"></i>
		</span>
		<span class="my-prev-button2">
			<i class="fa-solid fa-angle-right" aria-hidden="true"></i>
		</span>
		
		</div>
</div>


<section class="special_offers">
<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 pl-0 text-center">
				<div class="img_div">
					<img src="./images/lamp_1.png" class="img-fluid" alt="">
				</div>
			</div>
			<div class="col-md-8 align-self-center">
				<div class="content_div">
				<div class="titleBox ">
				<h1>Special Offers</h1>
				 </div>
					
					<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fugiat temporibus, eum fuga iusto modi rerum cum nihil 
						debitis ex facilis.</p>
				</div>
				
				
			<div id="specialOffer" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner">
				<div class="carousel-item active">
				<!-- <img class="d-block w-100" src="..." alt="First slide"> -->
				<div class="row">
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-02.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
				</div>
				</div>
				<div class="carousel-item">
				<div class="row">
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
				</div>
				<!-- <img class="d-block w-100" src="..." alt="Second slide"> -->
				</div>
				<div class="carousel-item">
				<div class="row">
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>
					</div>
				</div>
				<!-- <img class="d-block w-100" src="..." alt="Third slide"> -->
				</div>
			</div>
			<a class="carousel-control-prevs" href="#specialOffer" role="button" data-slide="prev">
				<!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span> -->
				<i class="fa fa-chevron-left" aria-hidden="true"></i>
			</a>
			<a class="carousel-control-nexts" href="#specialOffer" role="button" data-slide="next">
				<!-- <span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span> -->
				<i class="fa fa-chevron-right" aria-hidden="true"></i>
			</a>
			</div>

				
			</div>
		</div>
	</div>
	</section>


	<section class="furniture_section">
    <div class="container">
        <div class="row">

            <div class="col-md-12 text-center">

                <h2 class="furniture_heading">FURNITURES</h2>

                <p class="mb-2 furniture_paragraph">Filler text is text that shares some characteristics of a real written
                    text,
                    but is random or otherwise generated.</p>

                <p class="mb-4 furniture_paragraph">Filler text is text that shares some characteristics of a real written
                    text</p>

            </div>

            <div class="col-md-6 mb-3">
                <div class="furniture_content h-100">

                    <div class="furniture_img">
                        <img src="./images/home-01.png" class="img-fluid" alt="">
                    </div>

                    <div class="first_card_content">
                        <h2>LIVING & FAMILY ROOM</h2>
                        <P>Filler text is text that shares some characteristics of a real written text</P>
						<div class="card_button">
					<a href=""><i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    </div>

                  

                </div>

            </div>

            <div class="col-md-6 mb-3">

                <div class="furniture_content mb-3">

                    <div class="furniture_img_02">
					<img src="./images/home-03.png" class="img-fluid" alt="">
                    </div>

                    <div class="first_card_content">
                        <h2>Home Ofices</h2>
                        <P>Filler text is text that shares some characteristics of a real written text</P>
						<div class="card_button">
                        <a href=""><i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    </div>


                </div>

                <div class="furniture_content h-40">

                    <div class="furniture_img_03">
					<img src="./images/home-02.png" class="img-fluid" alt="">
                    </div>

                    <div class="first_card_content">
                        <h2>Bedrooms</h2>
                        <P>Filler text is text that shares some characteristics of a real written text</P>
						<div class="card_button">
                        <a href=""><i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    </div>

                  

                </div>

            </div>
<div class="col-md-12 my-3">
<div class="actionButton text-center">
			<button>View All</button>
		</div>
</div>
        </div>
    </div>
</section>


	<section class="browse_by_category">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
                 <div class="titleBox text-center">
					<h1>Browse By Category</h1>
				 </div>
				</div>



				<div class="col-md-12">
				<div id="browse_category_carousel" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="carousel-item active">
						
						<div class="all_category">
							<ul class="categories">
								<li>
									<img src="./images/b1.png" alt="">
									<h6>AREA RUGS</h6>
								</li>
								<li>
								<img src="./images/b2.png" alt="">
								<h6>BEDDING</h6>
								</li>
								<li>
								<img src="./images/b3.png" alt="">
								<h6>LIVING & FAMILY ROOM</h6>
								</li>
								<li>
								<img src="./images/b4.png" alt="">
								<h6>BEDROOM</h6>
								</li>
								<li>
								<img src="./images/b5.png" alt="">
								<h6>DINING ROOM</h6>
								</li>
							</ul>

						</div>
				
						<!-- <img class="d-block w-100" src="..." alt="First slide"> -->
						</div>
						<div class="carousel-item">
					
				<div class="all_category">

					<ul class="categories">
						<li>
							<img src="./images/b1.png" alt="">
							<h6>AREA RUGS</h6>
						</li>
						<li>
						<img src="./images/b2.png" alt="">
						<h6>BEDDING</h6>
						</li>
						<li>
						<img src="./images/b3.png" alt="">
						<h6>LIVING & FAMILY ROOM</h6>
						</li>
						<li>
						<img src="./images/b4.png" alt="">
						<h6>BEDROOM</h6>
						</li>
						<li>
                        <img src="./images/b5.png" alt="">
						<h6>DINING ROOM</h6>
						</li>
					</ul>

				</div>
	
						<!-- <img class="d-block w-100" src="..." alt="Second slide"> -->
						</div>
						<div class="carousel-item">
						
				<div class="all_category">

					<ul class="categories">
						<li>
							<img src="./images/b1.png" alt="">
							<h6>AREA RUGS</h6>
						</li>
						<li>
						<img src="./images/b2.png" alt="">
						<h6>BEDDING</h6>
						</li>
						<li>
						<img src="./images/b3.png" alt="">
						<h6>LIVING & FAMILY ROOM</h6>
						</li>
						<li>
						<img src="./images/b4.png" alt="">
						<h6>BEDROOM</h6>
						</li>
						<li>
                        <img src="./images/b5.png" alt="">
						<h6>DINING ROOM</h6>
						</li>
					</ul>

				</div>
		
						<!-- <img class="d-block w-100" src="..." alt="Third slide"> -->
						</div>
					</div>
					<a class="carousel-control-prevs" href="#browse_category_carousel" role="button" data-slide="prev">
						<!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span> -->
						<i class="fa fa-chevron-left" aria-hidden="true"></i>
					</a>
					<a class="carousel-control-nexts" href="#browse_category_carousel" role="button" data-slide="next">
						<!-- <span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span> -->
						<i class="fa fa-chevron-right" aria-hidden="true"></i>
					</a>
					</div>
				</div>

				
				
				<div class="browse-carousel owl-carousel owl-theme">
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-02.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
							<img src="./images/bestseller-01.png" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
				<div class="item">
				<div class="product_card">
						<div class="card_header">
							<div class="product_img">
								<img src="./images/p-1.jpg" class="img-fluid" alt="">
							</div>
							<div class="tag"><span>Best Seller</span></div>
						</div>
						<div class="card_body">
                            <div class="card_content">
							<h3>Lorem Ipsum dolor sit</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
							 <h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
								<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
							</div>
							<div class="cardBottom">
								<div class="similar_products">
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
									<div class="similar_img">
										<img src="./images/p-1.jpg" class="img-fluid" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="card_footer">
						    <div class="product_price">
								<h5>$25,275 <span>$39,630</span></h5>
							</div>
							<div class="cart">
								<p><i class="fa-solid fa-bag-shopping"></i></p>
							</div>
						</div>
						</div>

				</div>
			
			</div>
			</div>
			
		</div>
	</section>



	
<section class="happy_hour_section">

<div class="container">
	<div class="row">
		<div class="col-md-3 align-self-center">

			<div class="first_content">
				<p>20%OFF</p>
				<h2>HAPPY <br> HOURS</h2>
				<p>20-OCT-TO-2023</p>


			</div>
		</div>

		<div class="col-md-6">
			<div class="image_content">
				<img src="./images/chair-01.png" class="img-fluid" alt="">
			</div>

		</div>



		<div class="col-md-3 ">
			<div class="second_content">
				<p>Loud Over - Ear Headphones</p>
				<h3>WINTER SALE</h3>
				<label>Filler text is text that shares some characteristics of a real written text,
					but is random or otherwise generated.</label>
			</div>

			<div class="actionButton">
			<button>Shop Now</button>
		</div>
		</div>


	</div>
</div>
</div>

</section>

<section class="top_selling_products">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
		<div class="content_div">
		<div class="header_top">
		<div class="titleBox">
		<h1>Top Selling Products</h1>
		</div>
		<div class="actionButton">
			<button>View All</button>
		</div>
		</div>
		<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, est?</p>
		</div>
			</div>
		
		</div>
		<div class="top_selling_carousel owl-carousel owl-theme">
			<div class="item">
			<div class="product_card">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-01.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="item">
			<div class="product_card">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-02.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="item">
			<div class="product_card">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-01.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
   
			</div>
		<div class="my-owl-nav1">
		<span class="my-next-button1">
			<i class="fa-solid fa-angle-left" aria-hidden="true"></i>
		</span>
		<span class="my-prev-button1">
			<i class="fa-solid fa-angle-right" aria-hidden="true"></i>
		</span>
		
		</div>
	</div>
	</section>

<section class="winter_sale_section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 align-self-center">
                <div class="second_content">
                    <p>Loud Over - Ear Headphones</p>
                    <h3>WINTER SALE</h3>
                    <label>Filler text is text that shares some characteristics of a real written text,
                        but is random or otherwise generated.</label>
                </div>
				<div class="actionButton">
			<button>Shop Now</button>
		</div>
            </div>
            <div class="col-md-6">
                <div class="image_content">
                    <img src="./images/chair4.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-md-3 align-self-center">
                <div class="first_content ">
                    <p>20%OFF</p>
                    <h2>HAPPY <br> HOURS</h2>
                    <p>20-OCT-TO-2023</p>


                </div>
            </div>

        </div>
    </div>
</section>


	<section class="top_trending">
		<div class="container">
		<div class="row">
		<div class="col-md-12">
			<div class="content_div text-center mb-5">
			<div class="titleBox ">
			<h1>Top Trending Products</h1>
			</div>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit, est?</p>
			</div>
		</div>
		</div>
		<div class="top_trending_products_list">
		<div class="row">
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-01.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-02.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
				<img src="./images/bestseller-01.png" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
					<img src="./images/p-1.jpg" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
					<img src="./images/p-1.jpg" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
					<img src="./images/p-1.jpg" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
					<img src="./images/p-1.jpg" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
			<div class="col-md-3">
			<div class="product_card mb-3">
			<div class="card_header">
				<div class="product_img">
					<img src="./images/p-1.jpg" class="img-fluid" alt="">
				</div>
				<div class="tag"><span>Best Seller</span></div>
			</div>
			<div class="card_body">
				<div class="card_content">
				<h3>Lorem Ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Text of the printing</p>
					<h4>Reviews <span><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
					<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span></h4>
				</div>
				<div class="cardBottom">
					<div class="similar_products">
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
						<div class="similar_img">
							<img src="./images/p-1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="card_footer">
				<div class="product_price">
					<h5>$25,275 <span>$39,630</span></h5>
				</div>
				<div class="cart">
					<p><i class="fa-solid fa-bag-shopping"></i></p>
				</div>
			</div>
			</div>
			</div>
		</div>
		</div>
		</div>
	</section>

	

<section class="footer_top_section">

<div class="container">
	<div class="row">

		<div class="col-md-4">
			<div class="icon_and_content">
			<div class="end_icons">
			<!-- <i class="fa-solid fa-truck-fast"></i> -->
			<img src="./images/Nitish-Kumar-001_03.png" alt="">
			</div>
			<div class="icon_content">
			<h4>
				NATIONWIDE DELIVERIES
			</h4>
			<p>We are offering delivery all over Pakistan.</p>
			</div>
			
			</div>
		</div>

		<div class="col-md-4">

			<div class="icon_and_content">
			<div class="end_icons">
				<img src="./images/Nitish-Kumar-001_05.png" alt="">
			<!-- <i class="fa-solid fa-headset"></i> -->
			</div>
			<div class="icon_content">
			<h4>
				ONLINE SUPPORT
			</h4>
			<p>Technical Support 24/7</p>
			</div>
			
			</div>

		</div>

		<div class="col-md-4">

		<div class="icon_and_content">
			<div class="end_icons">
				<img src="./images/Nitish-Kumar-001_07.png" alt="">
			<!-- <i class="fa-solid fa-money-bill-trend-up"></i> -->
			</div>
			<div class="icon_content">
			<h4>
				MONEY BACK GUARANTEE
			</h4>
			<p>Technical Support 24/7</p>
			</div>
			
			</div>

		</div>



	</div>
</div>

</section>


<?php include 'inc/footer.php';?>
