import React from 'react'

function RecomendHeading() {
  return (
    <div><h3 className='mb-5'>Recommended for you</h3></div>
  )
}

export default RecomendHeading